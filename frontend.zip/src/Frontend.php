<?php

namespace Coredump\Frontend;

class Frontend
{
    // Build your next great package.
}
